CountryType = {
	Wei = 1,
	Shu = 2,
	Wu = 3,
	Qun = 4,
	
	[1] = {
		text = "WEI",
	},
	[2] = {
		text = "SHU",
	},
	[3] = {
		text = "WU",
	},
	[4] = {
		text = "QUN",
	},
}

SkillType = {
	Active = 1,
	Attack = 2,
	Passive = 3,
	Chain = 4,
	
	[1] = {
		text = "B",
	},
	[2] = {
		text = "A",
	},
	[3] = {
		text = "P",
	},
	[4] = {
		text = "C",
	},
}

ChainType = {
	Fall = 1,
	Back = 2,
	Float = 3,
	Fly = 4,
	
	[1] = {
		text = "FALL",
	},
	[2] = {
		text = "BACK",
	},
	[3] = {
		text = "FLOAT",
	},
	[4] = {
		text = "FLY",
	},
}