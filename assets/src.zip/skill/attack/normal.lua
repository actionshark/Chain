return {
	name = "NM",
	type = SkillType.Attack,
	
	onEvent = function(moment, data, context) {
	},
}