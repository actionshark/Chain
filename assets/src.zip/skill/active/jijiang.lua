return {
	name = "JJ",
	type = SkillType.Active,
	
	onCall = function(data, context) {
	},
}