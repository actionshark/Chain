return {
	name = "FF",
	type = SkillType.Chain,
	
	from = ChainType.Float,
	to = ChainType.Fly,
}