return {
	name = "BF",
	type = SkillType.Chain,
	
	from = ChainType.Back,
	to = ChainType.Float,
}