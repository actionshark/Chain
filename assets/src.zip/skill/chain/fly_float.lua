return {
	name = "BF",
	type = SkillType.Chain,
	
	from = ChainType.Fly,
	to = ChainType.Float,
}