return {
	name = "FF",
	type = SkillType.Chain,
	
	from = ChainType.Fly,
	to = ChainType.Fall,
}