return {
	name = "FF",
	type = SkillType.Chain,
	
	from = ChainType.Fall,
	to = ChainType.Float,
}