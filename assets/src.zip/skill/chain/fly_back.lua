return {
	name = "FB",
	type = SkillType.Chain,
	
	from = ChainType.Fly,
	to = ChainType.Back,
}