return {
	name = "RD",
	type = SkillType.Passive,
	
	onEvent = function(moment, data, context) {
	},
}