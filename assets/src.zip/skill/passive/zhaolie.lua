return {
	name = "ZL",
	type = SkillType.Passive,
	
	onEvent = function(moment, data, context) {
	},
}