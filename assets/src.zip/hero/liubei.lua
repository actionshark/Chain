return {
	name = "LB",
	country = CountryType.Shu,
	
	health = 1000,
	attack = 10,
	defence = 10,
	
	skill = {
		"active/jijiang",
		"attack/normal",
		"chain/back_float",
		"passive/rende",
		"passive/zhaolie",
	}
}